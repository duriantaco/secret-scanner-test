import argparse
import os
import re
import subprocess
import sys
from math import log2
from pathlib import Path

ENTROPY_THRESHOLD = 4.5
PATTERNS = {
    "AWS_ACCESS_KEY": r"AKIA[0-9A-Z]{16}",
    "AWS_SECRET_KEY": r"[A-Za-z0-9+/]{40}",
    "Google_API": r"AIza[0-9A-Za-z_\-]{35}",
    "Stripe_Live": r"sk_live_[0-9a-zA-Z]{24}",
    "Stripe_Test": r"sk_test_[0-9a-zA-Z]{24}",
    "OpenAI": r"sk-[A-Za-z0-9_\-]{20,}",
    "GitHub_Token": r"ghp_[A-Za-z0-9]{36}",
    "JWT": r"eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
    "Private_Key": r"-----BEGIN [A-Z ]+PRIVATE KEY-----",
    "API_Key_Generic": r"['\"]?[Aa][Pp][Ii][_]?[Kk][Ee][Yy]['\"]?\s*[:=]\s*['\"]([A-Za-z0-9+/]{16,})['\"]",
    "Bearer_Token": r"[Bb]earer\s+[A-Za-z0-9+/=]{20,}",
    "Anthropic": r"sk-ant-api03-[a-zA-Z0-9_-]{40,}",
    "Slack_Bot_Token": r"xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}",
    "Slack_User_Token": r"xoxp-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}",
    "Firebase_API_Key": r"AIza[0-9A-Za-z_\-]{35}",
    "Twilio_Account_SID": r"AC[a-fA-F0-9]{32}",
    "Twilio_Auth_Token": r"[a-fA-F0-9]{32}",
    "SendGrid_API_Key": r"SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}",
    "Discord_Bot_Token": r"[MNO][a-zA-Z\d_-]{23,25}\.[a-zA-Z\d_-]{6}\.[a-zA-Z\d_-]{27,39}",
    "AWS_TEMP_ACCESS_KEY": r"ASIA[0-9A-Z]{16}",
    "Deepseek": r"sk-[a-zA-Z0-9]{20,25}"

}

FALSE_POSITIVES = {
    "EXAMPLE_KEY_123456789",
    "API_KEY_HERE", 
    "REPLACE_WITH_YOUR_KEY",
    "xxxxxxxxxxxxxxxx",
    "sk-1234567890abcdef",
    "AKIAIOSFODNN7EXAMPLE",
}

class PreCommitGuard:
    def __init__(self, entropy_threshold=ENTROPY_THRESHOLD, strict_mode=False):
        self.entropy_threshold = entropy_threshold
        self.strict_mode = strict_mode
        self.violations = []
        
    def shannon_entropy(self, s):
        if not s or len(s) < 8: 
            return 0.0
        
        if re.match(r'^\d{10,13}$', s):
            return 0.0
        if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', s.lower()):  # UUID
            return 0.0
            
        p = [s.count(c) / len(s) for c in set(s)]
        return -sum(x * log2(x) for x in p if x > 0)


    def is_false_positive(self, token):
        return any(fp in token.upper() for fp in FALSE_POSITIVES)
    
    def is_test_file(self, filepath):
        test_indicators = ['test', 'spec', 'mock', 'fixture', 'sample', 'example']
        path_lower = filepath.lower()
        return any(indicator in path_lower for indicator in test_indicators)
    
    def scan_content(self, content, filepath):
        violations = []
        
        for line_num, line in enumerate(content.splitlines(), 1):
            stripped = line.strip()
            if any(stripped.startswith(comment) for comment in ['#', '//', '/*', '*', '--']):
                continue
                
            for name, pattern in PATTERNS.items():
                for match in re.finditer(pattern, line):
                    token = match.group(0)
                    if not self.is_false_positive(token):
                        violations.append({
                            'type': name,
                            'token': token,
                            'file': filepath,
                            'line': line_num,
                            'context': line.strip()[:100],
                            'severity': 'HIGH'
                        })
            
            if not (self.strict_mode and self.is_test_file(filepath)):
                for token in re.findall(r"[A-Za-z0-9+/]{20,}", line):
                    entropy = self.shannon_entropy(token)
                    if (entropy > self.entropy_threshold and 
                        not self.is_false_positive(token) and
                        not token.isdigit() and
                        not all(c.isalpha() for c in token)):
                        violations.append({
                            'type': 'HIGH_ENTROPY',
                            'token': token,
                            'file': filepath,
                            'line': line_num,
                            'context': line.strip()[:100],
                            'entropy': entropy,
                            'severity': 'MEDIUM'
                        })
        
        return violations
    
    def get_staged_files(self):
        try:
            result = subprocess.run(
                ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
                capture_output=True, text=True, check=True
            )
            return [f for f in result.stdout.strip().split('\n') if f]
        except subprocess.CalledProcessError:
            return []
    
    def get_file_content(self, filepath, staged=True):
        try:
            if staged:
                result = subprocess.run(
                    ["git", "show", f":{filepath}"],
                    capture_output=True, text=True, check=True
                )
                return result.stdout
            else:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
        except (subprocess.CalledProcessError, FileNotFoundError, UnicodeDecodeError):
            return ""
    
    def scan_staged_files(self):
        files = self.get_staged_files()
        all_violations = []
        
        for filepath in files:
            if any(filepath.endswith(ext) for ext in [
                '.jpg', '.jpeg', '.png', '.gif', '.pdf', '.exe', '.bin', 
                '.so', '.dll', '.dylib', '.zip', '.tar', '.gz'
            ]):
                continue
                
            content = self.get_file_content(filepath, staged=True)
            if content:
                violations = self.scan_content(content, filepath)
                all_violations.extend(violations)
        
        return all_violations
    
    def scan_files(self, filepaths):
        all_violations = []
        
        for filepath in filepaths:
            if not os.path.exists(filepath):
                continue
                
            content = self.get_file_content(filepath, staged=False)
            if content:
                violations = self.scan_content(content, filepath)
                all_violations.extend(violations)
        
        return all_violations
    
    def report_violations(self, violations):
        if not violations:
            return True
            
        print("🚨 SECURITY ALERT: Potential secrets detected!")
        print("=" * 60)
        
        high_severity = [v for v in violations if v['severity'] == 'HIGH']
        medium_severity = [v for v in violations if v['severity'] == 'MEDIUM']
        
        if high_severity:
            print(f"\n❌ HIGH SEVERITY ({len(high_severity)} violations):")
            for v in high_severity:
                print(f"  File: {v['file']}:{v['line']}")
                print(f"  Type: {v['type']}")
                print(f"  Token: {v['token'][:8]}...{v['token'][-4:]}")
                print(f"  Context: {v['context']}")
                print()
        
        if medium_severity:
            print(f"\n⚠️  MEDIUM SEVERITY ({len(medium_severity)} violations):")
            for v in medium_severity:
                entropy_info = f" (entropy: {v.get('entropy', 0):.2f})" if 'entropy' in v else ""
                print(f"  File: {v['file']}:{v['line']}")
                print(f"  Type: {v['type']}{entropy_info}")
                print(f"  Token: {v['token'][:8]}...{v['token'][-4:]}")
                print()
        
        print("🔧 To fix:")
        print("  1. Remove or redact the secrets from your files")
        print("  2. Add false positives to .secretsignore (if applicable)")
        print("  3. Use environment variables or secret management")
        print("  4. Re-run this check or attempt to commit again")
        
        return False
    
    def install_git_hook(self):
        git_dir = Path(".git")
        if not git_dir.exists():
            print("❌ Not in a git repository")
            return False
            
        hooks_dir = git_dir / "hooks"
        hooks_dir.mkdir(exist_ok=True)
        
        hook_file = hooks_dir / "pre-commit"
        
        hook_content = '''#!/usr/bin/env python3
    """Auto-generated pre-commit hook for secret detection"""
    import sys
    import subprocess
    import os

    hooks_dir = os.path.dirname(os.path.abspath(__file__))
    git_dir = os.path.dirname(hooks_dir)
    project_root = os.path.dirname(git_dir)

    sys.path.insert(0, project_root)

    snugbug_path = os.path.join(project_root, 'snugbug')
    if os.path.exists(snugbug_path):
        sys.path.insert(0, project_root)

    try:
        try:
            from snugbug.pre_commit_guard import PreCommitGuard
        except ImportError:
            from pre_commit_guard import PreCommitGuard
        
        guard = PreCommitGuard()
        violations = guard.scan_staged_files()
        
        if violations:
            guard.report_violations(violations)
            print("\\n❌ Commit rejected due to potential secrets.")
            print("Fix the issues above and try again.")
            sys.exit(1)
        else:
            print("✅ No secrets detected. Commit approved.")
            sys.exit(0)
            
    except ImportError as e:
        print(f"⚠️  Could not import pre_commit_guard: {{e}}")
        print("   Skipping secret check...")
        sys.exit(0)
    except Exception as e:
        print(f"⚠️  Error in pre-commit hook: {{e}}")
        sys.exit(0)  # Don't block commits on hook errors
    '''
        
        try:
            with open(hook_file, 'w') as f:
                f.write(hook_content)
            
            os.chmod(hook_file, 0o755)
            
            print(f"✅ Pre-commit hook installed at {hook_file}")
            print("   Commits will now be automatically checked for secrets.")
            return True
            
        except Exception as e:
            print(f"❌ Failed to install hook: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(description="Prevent secrets in git commits")
    parser.add_argument("--install-hook", action="store_true",
                       help="Install as git pre-commit hook")
    parser.add_argument("--scan-staged", action="store_true",
                       help="Scan staged files (for use in pre-commit hook)")
    parser.add_argument("--files", nargs="*",
                       help="Specific files to scan")
    parser.add_argument("--strict", action="store_true",
                       help="Strict mode (also check test files)")
    parser.add_argument("--entropy", type=float, default=ENTROPY_THRESHOLD,
                       help=f"Entropy threshold (default: {ENTROPY_THRESHOLD})")
    
    args = parser.parse_args()
    
    guard = PreCommitGuard(
        entropy_threshold=args.entropy,
        strict_mode=args.strict
    )
    
    if args.install_hook:
        success = guard.install_git_hook()
        sys.exit(0 if success else 1)
    
    if args.scan_staged:
        violations = guard.scan_staged_files()
    elif args.files:
        violations = guard.scan_files(args.files)
    else:
        try:
            subprocess.run(["git", "rev-parse", "--git-dir"], 
                          capture_output=True, check=True)
            violations = guard.scan_staged_files()
        except subprocess.CalledProcessError:
            print("Not in git repo, scanning current directory Python files...")
            py_files = list(Path(".").glob("*.py"))
            violations = guard.scan_files([str(f) for f in py_files])
    
    clean = guard.report_violations(violations)
    
    if violations:
        print(f"\n🔍 Found {len(violations)} potential secret(s)")
        sys.exit(1)
    else:
        print("✅ No secrets detected!")
        sys.exit(0)

if __name__ == "__main__":
    main()