import json
import subprocess
import tempfile
import os
import sys

class GitSecretsCleaner:
    def __init__(self, dry_run=False):
        self.dry_run = dry_run
        self.temp_dir = None
        
    def check_repo_clean(self):
        try:
            result = subprocess.run(["git", "status", "--porcelain"], 
                                capture_output=True, text=True)
            
            if result.stdout.strip():
                lines = result.stdout.strip().split('\n')
                
                safe_files = {
                    '.secrets_report.json',
                    '.leak_report.json', 
                    'secrets_report.json',
                    'leak_report.json',
                    '.gitignore' 
                }
                
                unsafe_changes = []
                for line in lines:
                    filename = line[3:].strip()  
                    
                    if filename not in safe_files:
                        unsafe_changes.append(line)
                
                if unsafe_changes:
                    print("❌ Repository has uncommitted changes. Please commit or stash first.")
                    print("Uncommitted files:")
                    for line in unsafe_changes:
                        print(f"   {line}")
                    return False
                else:
                    print("✅ Only tool-generated files are uncommitted, proceeding...")
                    return True
            return True
        except subprocess.CalledProcessError:
            print("❌ Not in a git repository")
            return False
    
    def create_backup(self):
        try:
            current_branch = subprocess.check_output(
                ["git", "branch", "--show-current"], text=True
            ).strip()
            
            backup_name = f"backup-before-cleaning-{current_branch}"
            
            try:
                subprocess.run(["git", "branch", "-D", backup_name], 
                             capture_output=True, check=False)
            except:
                pass
            
            subprocess.run(["git", "branch", backup_name], check=True)
            print(f"📦 Created backup: {backup_name}")
            return backup_name
            
        except subprocess.CalledProcessError as e:
            print(f"⚠️  Could not create backup: {e}")
            return None
    
    def get_all_commits(self):
        """Get all commit hashes"""
        try:
            result = subprocess.check_output(
                ["git", "rev-list", "--all", "--reverse"],
                text=True
            )
            return result.strip().split('\n') if result.strip() else []
        except subprocess.CalledProcessError:
            return []
    
    def get_commit_files(self, commit_hash):
        try:
            result = subprocess.check_output(
                ["git", "ls-tree", "-r", "--name-only", commit_hash],
                text=True
            )
            return result.strip().split('\n') if result.strip() else []
        except subprocess.CalledProcessError:
            return []
    
    def get_file_content(self, commit_hash, file_path):
        try:
            return subprocess.check_output(
                ["git", "show", f"{commit_hash}:{file_path}"],
                text=True, errors="ignore"
            )
        except subprocess.CalledProcessError:
            return None
    
    def apply_replacements(self, content, replacements):
        """Apply secret replacements to content"""
        modified_content = content
        replacements_made = []
        
        for secret_token, replacement in replacements.items():
            if secret_token in modified_content:
                modified_content = modified_content.replace(secret_token, replacement)
                replacements_made.append((secret_token, replacement))
        
        return modified_content, replacements_made
    
    def clean_history_simple(self, secrets):
        if not secrets:
            print("✅ No secrets to clean")
            return True
        
        replacements = {}
        for secret in secrets:
            token = secret['token']
            replacement = f"[REDACTED_{token[:4]}...{token[-4:]}]"
            replacements[token] = replacement
        
        print(f"🧹 Cleaning {len(secrets)} secrets from history...")
        print("Replacements to be made:")
        for i, (token, replacement) in enumerate(replacements.items(), 1):
            print(f"  {i}. {token[:10]}... → {replacement}")
        
        if self.dry_run:
            print("\n🔍 DRY RUN - Would clean these files:")
            for secret in secrets:
                print(f"   {secret['file']}:{secret['line']} - {secret['token'][:10]}...")
            return True
        
        confirm = input("\nThis will rewrite git history. Continue? (y/N): ")
        if confirm.lower() != 'y':
            print("❌ Cancelled")
            return False
        
        backup = self.create_backup()
        
        affected_files = set(secret['file'] for secret in secrets)
        
        print(f"\n🔄 Processing {len(affected_files)} affected files...")
        
        files_modified = []
        
        for file_path in affected_files:
            if not os.path.exists(file_path):
                continue
                
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            modified_content, replacements_made = self.apply_replacements(content, replacements)
            
            if replacements_made:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(modified_content)
                files_modified.append((file_path, len(replacements_made)))
                print(f"   ✓ {file_path}: {len(replacements_made)} secrets replaced")
        
        if files_modified:
            subprocess.run(["git", "add"] + [f[0] for f in files_modified], check=True)
            subprocess.run(["git", "commit", "-m", "🧹 Remove secrets from repository"], check=True)
            
            print(f"\n✅ Successfully cleaned {len(files_modified)} files!")
            print("\n📋 Next steps:")
            print("   1. Review changes: git show HEAD")
            print("   2. Push if needed: git push --force-with-lease")
            print("   3. Regenerate all cleaned API keys")
            if backup:
                print(f"   4. Delete backup when satisfied: git branch -D {backup}")
        else:
            print("⚠️  No files were modified (secrets may already be cleaned)")
        
        return True
    
    def clean_history_advanced(self, secrets):
        if not secrets:
            print("✅ No secrets to clean")
            return True
        
        replacements = {}
        for secret in secrets:
            token = secret['token']
            replacement = f"[REDACTED_{token[:4]}...{token[-4:]}]"
            replacements[token] = replacement
        
        print(f"🧹 Advanced cleaning: rewriting history for {len(secrets)} secrets...")
        
        if self.dry_run:
            print("\n🔍 DRY RUN - Would rewrite history for:")
            return True
        
        backup = self.create_backup()
        
        script_content = '''#!/bin/bash
    # Auto-generated script to clean secrets

    '''
        
        # Use | as delimiter instead of / to avoid conflicts
        for token, replacement in replacements.items():
            # Escape special characters for sed
            escaped_token = token.replace("\\", "\\\\").replace("|", "\\|")
            escaped_replacement = replacement.replace("\\", "\\\\").replace("|", "\\|")
            
            # Use | as delimiter and target all files, not just .py
            script_content += f"find . -type f -exec sed -i 's|{escaped_token}|{escaped_replacement}|g' {{}} + 2>/dev/null || true\n"
        
        script_path = tempfile.mktemp(suffix='.sh')
        with open(script_path, 'w') as f:
            f.write(script_content)
        os.chmod(script_path, 0o755)
        
        try:
            print("🔄 Running git filter-branch...")
            cmd = [
                "git", "filter-branch", "--force", "--tree-filter", script_path, "--", "--all"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ History rewritten successfully!")
                
                # Clean up filter-branch refs
                subprocess.run(["git", "for-each-ref", "--format=delete %(refname)", 
                            "refs/original"], capture_output=True, text=True, 
                            input="delete", check=False)
                
                print("\n📋 Next steps:")
                print("   1. Review history: git log --oneline")
                print("   2. Force push: git push --force-with-lease")
                print("   3. Regenerate cleaned API keys")
                return True
            else:
                print(f"❌ Filter-branch failed: {result.stderr}")
                return False
                
        finally:
            os.unlink(script_path)
    
    def load_secrets(self, report_file):
        """Load secrets from report file"""
        try:
            with open(report_file, 'r') as f:
                report = json.load(f)
            return report.get('secrets', [])
        except FileNotFoundError:
            print(f"❌ Report file not found: {report_file}")
            print("Run the scanner first to generate the report.")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in report: {e}")
            return None

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Custom Git History Cleaner")
    parser.add_argument("--report", "-r", default=".secrets_report.json",
                       help="Secrets report file")
    parser.add_argument("--dry-run", action="store_true",
                       help="Show what would be done")
    parser.add_argument("--method", choices=["simple", "advanced"], default="simple",
                       help="Cleaning method (simple=current files, advanced=full history)")
    
    args = parser.parse_args()
    
    cleaner = GitSecretsCleaner(dry_run=args.dry_run)
    
    if not cleaner.check_repo_clean():
        sys.exit(1)
    
    secrets = cleaner.load_secrets(args.report)
    if secrets is None:
        sys.exit(1)
    
    if not secrets:
        print("✅ No secrets found in report")
        sys.exit(0)
    
    print(f"📊 Found {len(secrets)} secrets to clean")
    
    if args.method == "simple":
        success = cleaner.clean_history_simple(secrets)
    else:
        success = cleaner.clean_history_advanced(secrets)
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()