import argparse
import sys
from pathlib import Path

from snugbug.secret_scanner import SecretScanner
from snugbug.git_secrets_cleaner import GitSecretsCleaner
from snugbug.pre_commit_guard import PreCommitGuard
from snugbug.secret_guardian import SecretGuardian

def create_parser():
    parser = argparse.ArgumentParser(
        prog='snugbug',
        description='🛡️ Snug Bug - Complete Git secret management toolkit',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  snugbug scan --all      
  snugbug scan --recent 50      
  snugbug clean
  snugbug clean --dry-run 
  snugbug guard --install 
  snugbug guard --check-staged 
  snugbug protect                      
  snugbug protect --recent 100 
        '''
    )
    
    parser.add_argument('--version', action='version', version='Secret Guardian 1.0.0')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    scan_parser = subparsers.add_parser(
        'scan', 
        help='Scan git history for secrets',
        description='Scan git repository for potential secrets using patterns and entropy analysis'
    )
    scan_group = scan_parser.add_mutually_exclusive_group(required=True)
    scan_group.add_argument('--all', action='store_true', help='Scan all commits')
    scan_group.add_argument('--recent', type=int, metavar='N', help='Scan last N commits')
    scan_parser.add_argument('--output', '-o', default='.secrets_report.json', 
                           help='Output JSON file (default: .secrets_report.json)')
    scan_parser.add_argument('--entropy', type=float, default=4.5,
                           help='Entropy threshold for detection (default: 4.5)')
    
    clean_parser = subparsers.add_parser(
        'clean',
        help='Clean secrets from git history', 
        description='Remove secrets from git history'
    )
    clean_parser.add_argument('--report', '-r', default='.secrets_report.json',
                            help='Path to secrets report JSON file')
    clean_parser.add_argument('--dry-run', action='store_true',
                            help='Show what would be done without executing')
    clean_parser.add_argument('--method', choices=['simple', 'advanced'], default='simple',
                            help='Cleaning method (simple=current files, advanced=full history)')
    
    guard_parser = subparsers.add_parser(
        'guard', 
        help='Prevent secrets in future commits',
        description='Install and manage pre-commit hooks to prevent secrets'
    )
    guard_group = guard_parser.add_mutually_exclusive_group(required=True)
    guard_group.add_argument('--install', action='store_true', 
                           help='Install pre-commit hook')
    guard_group.add_argument('--check-staged', action='store_true',
                           help='Check staged files for secrets')
    guard_group.add_argument('--check-files', nargs='+', metavar='FILE',
                           help='Check specific files for secrets')
    guard_group.add_argument('--check-dir', metavar='DIR', 
                           help='Check directory for secrets')
    guard_parser.add_argument('--strict', action='store_true',
                            help='Strict mode (also check test files)')
    guard_parser.add_argument('--entropy', type=float, default=4.5,
                            help='Entropy threshold (default: 4.5)')
    
    protect_parser = subparsers.add_parser(
        'protect',
        help='Complete protection workflow',
        description='Full workflow: scan for secrets, clean history, and setup protection'
    )
    protect_parser.add_argument('--recent', type=int, metavar='N',
                              help='Only scan last N commits (default: all commits)')
    protect_parser.add_argument('--dry-run', action='store_true',
                              help='Show what would be done without executing')
    protect_parser.add_argument('--method', choices=['simple', 'advanced'], default='simple',
                              help='Cleaning method (simple=current files, advanced=full history)')
    protect_parser.add_argument('--report', default='.secrets_report.json',
                              help='Path to secrets report file')
    
    status_parser = subparsers.add_parser(
        'status',
        help='Show repository security status',
        description='Display current security status and recommendations'
    )
    
    return parser

def cmd_scan(args):
    print("🔍 Scanning repository for secrets...")
    
    scanner = SecretScanner(entropy_threshold=args.entropy)
    
    if args.all:
        secrets = scanner.scan_commits(all_commits=True)
    else:
        secrets = scanner.scan_commits(recent=args.recent)
    
    report = scanner.generate_report(secrets, args.output)
    
    return 0 if not secrets else 1

def cmd_clean(args):
    print("🧹 Cleaning secrets from git history...")
    
    cleaner = GitSecretsCleaner(dry_run=args.dry_run)
    
    if not cleaner.check_repo_clean():
        return 1
    
    secrets = cleaner.load_secrets(args.report)
    if secrets is None:
        return 1
    
    if args.method == "simple":
        success = cleaner.clean_history_simple(secrets)
    else:
        success = cleaner.clean_history_advanced(secrets)
    
    return 0 if success else 1

def cmd_guard(args):
    guard = PreCommitGuard(
        entropy_threshold=args.entropy,
        strict_mode=args.strict
    )
    
    if args.install:
        print("🛡️ Installing pre-commit hook...")
        success = guard.install_git_hook()
        return 0 if success else 1
        
    elif args.check_staged:
        print("🔍 Checking staged files...")
        violations = guard.scan_staged_files()
        clean = guard.report_violations(violations)
        return 0 if clean and not violations else 1
        
    elif args.check_files:
        print(f"🔍 Checking {len(args.check_files)} files...")
        violations = guard.scan_files(args.check_files)
        clean = guard.report_violations(violations)
        return 0 if clean and not violations else 1
        
    elif args.check_dir:
        print(f"🔍 Checking directory: {args.check_dir}")
        py_files = list(Path(args.check_dir).glob("**/*.py"))
        violations = guard.scan_files([str(f) for f in py_files])
        clean = guard.report_violations(violations)
        return 0 if clean and not violations else 1

def cmd_protect(args):
    print("🛡️ Starting complete protection workflow...")
    
    guardian = SecretGuardian()
    guardian.report_file = args.report
    
    if not guardian.check_git_repo():
        return 1
    
    success = guardian.full_scan_and_clean(
        recent_commits=args.recent,
        dry_run=args.dry_run,
        method=args.method
    )
    
    return 0 if success else 1

def cmd_status(args):
    print("📊 Repository Security Status")
    print("=" * 40)
    
    guardian = SecretGuardian()
    
    if not guardian.check_git_repo():
        print("❌ Not in a git repository")
        return 1
    
    repo_info = guardian.get_repo_info()
    if repo_info:
        print(f"Branch: {repo_info['branch']}")
        print(f"Commits: {repo_info['commit_count']}")
        print(f"Remote: {repo_info['remote']}")
    
    hook_path = Path(".git/hooks/pre-commit")
    if hook_path.exists():
        print("✅ Pre-commit hook: Installed")
    else:
        print("❌ Pre-commit hook: Not installed")
        print("   Run: snugbug guard --install")
    
    report_path = Path(".secrets_report.json")
    if report_path.exists():
        try:
            import json
            with open(report_path) as f:
                report = json.load(f)
            secret_count = len(report.get('secrets', []))
            print(f"📄 Last scan: {secret_count} secrets found")
            if secret_count > 0:
                print("⚠️  Secrets detected in last scan!")
                print("   Run: snugbug clean")
        except:
            print("📄 Last scan: Report file corrupted")
    else:
        print("📄 Last scan: No report found")
        print("   Run: snugbug scan --recent 50")
    
    print("\n🔍 Quick scan of current directory...")
    guard = PreCommitGuard()
    py_files = list(Path(".").glob("*.py"))[:5]
    if py_files:
        violations = guard.scan_files([str(f) for f in py_files])
        if violations:
            print(f"⚠️  {len(violations)} potential secrets in current files")
        else:
            print("✅ No obvious secrets in current Python files")
    
    print("\n💡 Recommendations:")
    print("   1. Run full scan: snugbug scan --all")
    print("   2. Install protection: snugbug guard --install") 
    print("   3. For full cleanup: snugbug protect")
    
    return 0

def main(argv=None):
    parser = create_parser()
    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        parser.print_help()
        return 0

    try:
        args = parser.parse_args(argv)

        if args.command == 'scan':
            return cmd_scan(args)
        elif args.command == 'clean':
            return cmd_clean(args)
        elif args.command == 'guard':
            return cmd_guard(args)
        elif args.command == 'protect':
            return cmd_protect(args)
        elif args.command == 'status':
            return cmd_status(args)
        else:
            parser.print_help()
            return 1

    except KeyboardInterrupt:
        print("\n❌ Operation cancelled by user")
        return 1
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main())