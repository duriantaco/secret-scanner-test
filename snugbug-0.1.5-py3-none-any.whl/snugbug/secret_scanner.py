import argparse, json, re, subprocess, sys
from collections import defaultdict
from math import log2
from pathlib import Path

ENTROPY_THRESHOLD = 4.5
PATTERNS = {
    "AWS_ACCESS_KEY": r"AKIA[0-9A-Z]{16}",
    "AWS_SECRET_KEY": r"[A-Za-z0-9+/]{40}",
    "Google_API": r"AIza[0-9A-Za-z_\-]{35}",
    "Stripe_Live": r"sk_live_[0-9a-zA-Z]{24}",
    "Stripe_Test": r"sk_test_[0-9a-zA-Z]{24}",
    "OpenAI": r"sk-[A-Za-z0-9_\-]{20,}",
    "GitHub_Token": r"ghp_[A-Za-z0-9]{36}",
    "JWT": r"eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
    "Private_Key": r"-----BEGIN [A-Z ]+PRIVATE KEY-----",
    "API_Key_Generic": r"['\"]?[Aa][Pp][Ii][_]?[Kk][Ee][Yy]['\"]?\s*[:=]\s*['\"]([A-Za-z0-9+/]{16,})['\"]",
    "Bearer_Token": r"[Bb]earer\s+[A-Za-z0-9+/=]{20,}",
    "Anthropic": r"sk-ant-api03-[a-zA-Z0-9_-]{40,}",
    "Slack_Bot_Token": r"xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}",
    "Slack_User_Token": r"xoxp-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}",
    "Firebase_API_Key": r"AIza[0-9A-Za-z_\-]{35}",
    "Twilio_Account_SID": r"AC[a-fA-F0-9]{32}",
    "Twilio_Auth_Token": r"[a-fA-F0-9]{32}",
    "SendGrid_API_Key": r"SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}",
    "Discord_Bot_Token": r"[MNO][a-zA-Z\d_-]{23,25}\.[a-zA-Z\d_-]{6}\.[a-zA-Z\d_-]{27,39}",
    "AWS_TEMP_ACCESS_KEY": r"ASIA[0-9A-Z]{16}",
    "Deepseek": r"sk-[a-zA-Z0-9]{20,25}"

}

FALSE_POSITIVES = {
    "EXAMPLE_KEY_123456789",
    "YOUR_API_KEY_HERE", 
    "REPLACE_WITH_YOUR_KEY",
    "xxxxxxxxxxxxxxxx",
    "1234567890abcdef1234567890abcdef12345678",
    "AKIAIOSFODNN7EXAMPLE",
    "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
}

EXCLUDED_FILES = {
    '.secrets_report.json',
    '.leak_report.json', 
    'secrets_report.json',
    'leak_report.json',
}

BINARY_EXTENSIONS = {
    '.jpg', '.jpeg', '.png', '.gif', '.pdf', '.exe', '.bin', '.zip', 
    '.tar', '.gz', '.mp4', '.mp3', '.avi', '.mov', '.ico', '.woff',
    '.woff2', '.ttf', '.eot'
}

class SecretScanner:
    def __init__(self, entropy_threshold=ENTROPY_THRESHOLD):
        self.entropy_threshold = entropy_threshold
        self.first_seen = defaultdict(lambda: None)
        
    def sh(self, cmd):
        return subprocess.check_output(cmd, text=True).strip().splitlines()

    def get_current_branch(self):
        try:
            return subprocess.check_output(
                ["git", "branch", "--show-current"], 
                text=True
            ).strip()
        except subprocess.CalledProcessError:
            return "unknown"

    def shannon_entropy(self, s):
        if not s or len(s) < 4:
            return 0.0
        p = [s.count(c) / len(s) for c in set(s)]
        return -sum(x * log2(x) for x in p if x > 0)

    def is_false_positive(self, token):
        """Enhanced false positive detection"""
        if any(fp in token.upper() for fp in FALSE_POSITIVES):
            return True
            
        if len(token) == 40 and all(c in '0123456789abcdef' for c in token.lower()):
            return True
            
        if len(token) == 64 and all(c in '0123456789abcdef' for c in token.lower()):
            return True
            
        if token.upper() in ['REDACTED', '[REDACTED]'] or 'REDACTED' in token.upper():
            return True
            
        if len(set(token)) == 1:
            return True
            
        return False

    def should_skip_file(self, file_path):
        """Check if file should be skipped"""
        if any(excluded in file_path for excluded in EXCLUDED_FILES):
            return True
            
        if any(file_path.lower().endswith(ext) for ext in BINARY_EXTENSIONS):
            return True
            
        path_parts = file_path.split('/')
        for part in path_parts:
            if part.startswith('.') and part not in ['.git', '.github']:
                return True
                
        return False

    def suspicious_strings(self, blob, file_path=""):
        suspects = []
        for line_num, line in enumerate(blob.splitlines(), 1):
            stripped = line.strip()
            
            if stripped.startswith('#') or 'test' in stripped.lower():
                continue
                
            if any(indicator in line for indicator in ['"commit":', '"token":', '"type":', '"secrets":']):
                continue
                
            for name, pat in PATTERNS.items():
                for m in re.finditer(pat, line):
                    token = m.group(0)
                    if not self.is_false_positive(token):
                        suspects.append((token, name, line_num, line.strip()[:100]))
                        
            for token in re.findall(r"[A-Za-z0-9+/]{20,}", line):
                if (self.shannon_entropy(token) > self.entropy_threshold and 
                    not self.is_false_positive(token) and
                    not any(c.isdigit() for c in token[:5])):
                    suspects.append((token, "HIGH-ENTROPY", line_num, line.strip()[:100]))
                    
        return suspects

    def scan_commits(self, recent=None, all_commits=False):
        current_branch = self.get_current_branch()
        print(f"Scanning branch: {current_branch}")
        
        if all_commits:
            commits = self.sh(["git", "rev-list", "--reverse", "--all"])
        elif recent:
            commits = self.sh(["git", "rev-list", "--reverse", f"-n{recent}", "HEAD"])
        else:
            commits = self.sh(["git", "rev-list", "--reverse", "-n10", "HEAD"])

        print(f"🔍 Scanning {len(commits)} commits...")
        secrets_found = []
        
        for i, commit_hash in enumerate(commits, 1):
            if i % 10 == 0:
                print(f"   Processed {i}/{len(commits)} commits...")
                
            try:
                files = self.sh(["git", "ls-tree", "-r", "--name-only", commit_hash])
                
                for file_path in files:
                    if self.should_skip_file(file_path):
                        continue
                        
                    try:
                        blob = subprocess.check_output(
                            ["git", "show", f"{commit_hash}:{file_path}"], 
                            text=True, errors="ignore"
                        )
                        
                        for token, label, line_num, context in self.suspicious_strings(blob, file_path):
                            if self.first_seen[token] is None:
                                try:
                                    commit_info = subprocess.check_output(
                                        ["git", "show", "--format=%an|%ad|%s", "--no-patch", commit_hash],
                                        text=True
                                    ).strip().split('|')
                                    author = commit_info[0] if len(commit_info) > 0 else "unknown"
                                    date = commit_info[1] if len(commit_info) > 1 else "unknown"
                                    message = commit_info[2] if len(commit_info) > 2 else "unknown"
                                except:
                                    author = date = message = "unknown"
                                
                                secret_info = {
                                    'token': token,
                                    'type': label,
                                    'commit': commit_hash,
                                    'branch': current_branch,
                                    'author': author,
                                    'date': date,
                                    'message': message[:50] + "..." if len(message) > 50 else message,
                                    'file': file_path,
                                    'line': line_num,
                                    'context': context,
                                    'entropy': self.shannon_entropy(token)
                                }
                                self.first_seen[token] = secret_info
                                secrets_found.append(secret_info)
                                
                    except subprocess.CalledProcessError:
                        continue
                        
            except subprocess.CalledProcessError:
                continue

        return secrets_found

    def generate_report(self, secrets, output_file=None):
        if not secrets:
            print("✅ No secrets found!")
            print("🛡️ Repository appears clean!")
            return {}

        print(f"\n🔑 Found {len(secrets)} potential secrets:")
        print("=" * 80)
        
        by_type = defaultdict(list)
        for secret in secrets:
            by_type[secret['type']].append(secret)
        
        print(f"\n📊 Summary by type:")
        for secret_type, secret_list in by_type.items():
            print(f"   {secret_type}: {len(secret_list)} found")
        
        print("\n🔍 Detailed findings:")
        print("=" * 80)
        
        for secret in secrets:
            print(f"""
Type     : {secret['type']}
Branch   : {secret['branch']}
Commit   : {secret['commit'][:10]} ({secret['date']})
Author   : {secret['author']}
Message  : {secret['message']}
File     : {secret['file']}
Line     : {secret['line']}
Token    : {secret['token'][:8]}...{secret['token'][-4:]} (len={len(secret['token'])}, entropy={secret['entropy']:.2f})
Context  : {secret['context']}
{'-' * 80}""")

        report_data = {
            'scan_info': {
                'branch': secrets[0]['branch'] if secrets else 'unknown',
                'total_secrets': len(secrets),
                'scan_date': subprocess.check_output(['date'], text=True).strip(),
                'by_type': {k: len(v) for k, v in by_type.items()}
            },
            'secrets': secrets
        }

        if output_file:
            gitignore_path = Path(".gitignore")
            if gitignore_path.exists():
                with open(gitignore_path, 'r') as f:
                    content = f.read()
            else:
                content = ""
                
            if output_file not in content:
                with open(gitignore_path, 'a') as f:
                    if content and not content.endswith('\n'):
                        f.write('\n')
                    f.write(f"\n# Secret scanner reports\n{output_file}\n")
                print(f"✅ Added {output_file} to .gitignore")
            
            with open(output_file, "w") as f:
                json.dump(report_data, f, indent=2)
            print(f"\n📄 Detailed report saved to: {output_file}")
        
        return report_data

def main():
    ap = argparse.ArgumentParser(description="Enhanced secret scanner for Git repositories")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--recent", type=int, metavar="N", help="Scan last N commits")
    g.add_argument("--all", action="store_true", help="Scan all commits")
    ap.add_argument("--output", "-o", default=".secrets_report.json", 
                   help="Output JSON file (default: .secrets_report.json)")
    ap.add_argument("--entropy", type=float, default=ENTROPY_THRESHOLD,
                   help=f"Entropy threshold (default: {ENTROPY_THRESHOLD})")
    ap.add_argument("--branch", help="Scan specific branch (default: current)")
    
    args = ap.parse_args()

    if args.branch:
        try:
            subprocess.run(["git", "checkout", args.branch], check=True, capture_output=True)
            print(f"✓ Switched to branch: {args.branch}")
        except subprocess.CalledProcessError:
            print(f"❌ Failed to switch to branch: {args.branch}")
            sys.exit(1)

    scanner = SecretScanner(entropy_threshold=args.entropy)
    secrets = scanner.scan_commits(recent=args.recent, all_commits=args.all)
    report = scanner.generate_report(secrets, args.output)
    
    if secrets:
        print(f"\n🚨 NEXT STEPS:")
        print(f"   1. Add {args.output} to .gitignore")
        print(f"   2. Use 'snugbug clean' to remove secrets from history")
        print(f"   3. Rotate any real credentials found")
    
    sys.exit(1 if secrets else 0)

if __name__ == "__main__":
    main()